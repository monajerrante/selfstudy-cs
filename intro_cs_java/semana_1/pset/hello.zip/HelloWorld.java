/******************************************************************
 * HelloWorld.java
 * Problem Set 1.
 * Problem 0. Clasical "Hello World"
 ******************************************************************/
 
public class HelloWorld{
    public static void main(String[] argv){
        System.out.println("Hello, World");
    }
}
